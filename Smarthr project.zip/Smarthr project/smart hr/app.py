
# #  API for future prediction of samrt hr 
# # ----------------------------------------------------------------------
from flask import Flask, jsonify, request
import joblib
import pandas as pd
from prophet import Prophet
from pymongo import MongoClient


app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['admin']  # Replace with your database name
#  Create two collections
data_collection = db['data'] 


# Load the trained model
model = joblib.load('D:/Smarthr project/smart hr/prophet_model.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    # Get the JSON data from the request
    data = list(data_collection.find({}))  # Expecting a JSON payload

    # Convert the received data to a DataFrame
    df = pd.DataFrame(data)

    # Preprocess the data
    df["loginAt"] = pd.to_datetime(df["loginAt"])
    df["Date"] = df["loginAt"].dt.date

    # Group by Date and count unique employeeIds
    employee_count = df.groupby('Date')['employeeId'].nunique().reset_index()
    
    # Rename the DataFrame for Prophet
    ds = employee_count.rename(columns={'Date': 'ds', 'employeeId': 'y'})

    last_date = ds['ds'].max()


    # Create a new DataFrame for the next month
    future_dates = pd.date_range(start=last_date+ pd.Timedelta(days=1), periods=6, freq='D')
    future_df = pd.DataFrame({'ds': future_dates})

    # Fit the model on the existing data
      
    # Predict using the model
    forecast = model.predict(future_df)

    # Prepare the response with only employee counts
    response = {
        'predictions': forecast[['ds', 'yhat']].to_dict(orient='records')  # Only include yhat for employee counts
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
# from flask import Flask, jsonify, request
# import joblib
# import pandas as pd
# from prophet import Prophet
# from pymongo import MongoClient

# app = Flask(__name__)

# # Connect to MongoDB
# client = MongoClient('mongodb://localhost:27017/')
# db = client['admin']  # Replace with your database name
# data_collection = db['data']  # Collection containing employee login data

# # Load the trained model
# model = joblib.load('D:/Smarthr project/smart hr/prophet_model.pkl')

# @app.route('/predict', methods=['POST'])
# def predict():
#     # Get the JSON data from the request
#     data = list(data_collection.find({}))  # Fetching all data

#     # Convert the received data to a DataFrame
#     df = pd.DataFrame(data)

#     # Preprocess the data
#     df["loginAt"] = pd.to_datetime(df["loginAt"])
#     df["Date"] = df["loginAt"].dt.date

#     # Group by Date and count unique employeeIds for historical data
#     historical_data = df.groupby('Date')['employeeId'].nunique().reset_index()
#     historical_data = historical_data.rename(columns={'Date': 'ds', 'employeeId': 'y'})

#     # Rename the DataFrame for Prophet
#     ds = historical_data.rename(columns={'ds': 'ds', 'y': 'y'})

#     last_date = historical_data['ds'].max()

#     # Create a new DataFrame for the next month
#     future_dates = pd.date_range(start=last_date+ pd.Timedelta(days=1), periods=30, freq='D')
#     future_df = pd.DataFrame({'ds': future_dates})

#     # Fit the model on the historical data
#     # model.fit(ds)

#     # Predict using the model
#     forecast = model.predict(future_df)

#     # Prepare the response with both historical and future predictions
#     response = {
#         'historical': historical_data.to_dict(orient='records'),  # Historical employee counts
#         'predictions': forecast[['ds', 'yhat']].to_dict(orient='records')  # Future predictions
#     }
    
#     return jsonify(response)

# if __name__ == '__main__':
#     app.run(debug=True)
