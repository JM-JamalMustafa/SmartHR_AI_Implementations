from flask import Flask, jsonify, send_from_directory
import pandas as pd
from datetime import datetime, timedelta
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['admin']  # Replace with your database name
#  Create two collections
data_collection = db['data']  # Replace with your actual collection name
leave_collection = db['leave']  # Replace with your actual collection name  
leavedate_collection = db['leave dates']

@app.route('/api/analytics/today', methods=['GET'])
def get_today_analytics():
    """API endpoint to retrieve today's analytics data."""
    today = datetime.now().date()

    data = list(data_collection.find({}))

    # Convert mock data to DataFrame
    df = pd.DataFrame(data)

    # Convert 'loginAt' to datetime
    df['loginAt'] = pd.to_datetime(df['loginAt'])

    # Filter for today's logins
    df_today = df[df['loginAt'].dt.date == today]

    # Extract hour of day
    df_today['hour'] = df_today['loginAt'].dt.hour

    # Separate check-ins and check-outs
    check_ins_by_hour = df_today[df_today['isCompleted'] == False]['hour'].value_counts().sort_index()
    check_outs_by_hour = df_today[df_today['isCompleted'] == True]['hour'].value_counts().sort_index()

    # Return check-in and check-out counts
    return jsonify({
        'check_ins': check_ins_by_hour.to_dict(),
        'check_outs': check_outs_by_hour.to_dict(),
    })

@app.route('/api/analytics/department-leave', methods=['GET'])
def get_department_leave_counts():
    """API endpoint to retrieve leave counts by department."""
    # Fetch data from both collections
    employee_data = pd.DataFrame(list(leavedate_collection.find({})))
    leave_data = pd.DataFrame(list(leave_collection.find({})))

    
    # Ensure that employeeId is in both DataFrames
    if 'employeeId' not in employee_data.columns or 'employeeId' not in leave_data.columns:
        return jsonify({"error": "Missing employeeId column in one of the collections."}), 500

    # Merge DataFrames on employeeId
    merged_df = pd.merge(employee_data, leave_data, on="employeeId", how="left")

    # Calculate total leave days
    merged_df['total_leave_days'] = merged_df[['annual_days', 'sick_days', 'emergency_days', 'compensatory_days']].sum(axis=1)

    # Count leave requests by department based on total_leave_days
    department_leave_counts = merged_df.groupby('category')['total_leave_days'].count().reset_index()
    department_leave_counts.columns = ['category', 'leave_count']

    # Sort the result by leave_count in descending order
    department_leave_counts = department_leave_counts.sort_values(by='leave_count', ascending=False)

    # Print the result for debugging purposes
    print(department_leave_counts)

    # Convert the result to a dictionary
    leave_counts_dict = {row['category']: row['leave_count'] for index, row in department_leave_counts.iterrows()}

    return jsonify(leave_counts_dict)


@app.route('/api/analytics/login-frequency', methods=['GET'])
def get_login_frequency():
    """API endpoint to retrieve login frequency by day of the week."""
    data = list(data_collection.find({}))

    df = pd.DataFrame(data)

    # Convert 'loginAt' to datetime
    df['loginAt'] = pd.to_datetime(df['loginAt'])

    # Extract day of the week
    df['day_of_week'] = df['loginAt'].dt.day_name()

    # Count logins per day of the week
    login_by_day = df['day_of_week'].value_counts()

    return jsonify(login_by_day.to_dict())

# @app.route('/')
# def index():
#     return send_from_directory('', 'index.html')

if __name__ == '__main__':
    app.run(debug=True)
