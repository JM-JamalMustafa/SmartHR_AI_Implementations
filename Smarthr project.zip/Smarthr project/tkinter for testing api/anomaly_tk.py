import tkinter as tk
from tkinter import messagebox
import requests
import folium
from folium import Marker
import webbrowser
import os

def fetch_and_plot():
    try:
        # Make a request to the Flask API
        response = requests.post('http://localhost:5000/predict')
        data = response.json()

        if 'error' in data:
            messagebox.showerror("Error", data['error'])
            return

        # Create a Folium map centered around the office location
        office_location = (24.434181, 56.580044)
        m = folium.Map(location=office_location, zoom_start=10)

        # Loop through the predictions and plot them on the map
        for predictions in data['predictions']:
            employee_id = predictions['employeeId']
            distance = predictions['distance_from_office']
            status = predictions['status']
            latitude = predictions['location']['latitude']
            longitude = predictions['location']['longitude']
            # Use different colors for normal and anomalies
            color = 'blue' if status == 'Normal' else 'red'  # Use blue for normal and red for anomalies

            # Add a marker for each prediction using the employee's location
            Marker(
                location=(latitude, longitude),  # Use employee's latitude and longitude
                popup=f'ID: {employee_id}, Distance: {distance:.2f} km, Status: {status}',
                icon=folium.Icon(color=color)
            ).add_to(m)

        # Save the map to an HTML file
        map_file = 'anomaly_map.html'
        m.save(map_file)

        # Open the map in the web browser
        webbrowser.open('file://' + os.path.realpath(map_file))

    except Exception as e:
        messagebox.showerror("Error", str(e))


# Create the main window
root = tk.Tk()
root.title("Anomaly Detection Visualization")

# Create a button to fetch and plot anomalies
fetch_button = tk.Button(root, text="Fetch Anomalies", command=fetch_and_plot)
fetch_button.pack(pady=20)

# Run the application
root.mainloop()
