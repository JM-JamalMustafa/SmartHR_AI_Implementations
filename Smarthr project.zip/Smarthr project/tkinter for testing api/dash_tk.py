import tkinter as tk
from tkinter import messagebox
import requests
import plotly.express as px
import plotly.io as pio
from plotly.offline import plot
import pandas as pd
# Set Plotly to render offline
pio.renderers.default = "browser"

# Function to get today's analytics
def fetch_today_analytics():
    try:
        response = requests.get('http://localhost:5000/api/analytics/today')
        response.raise_for_status()
        data = response.json()
        
        # Create a bar plot for check-ins and check-outs
        check_ins = data.get('check_ins', {})
        check_outs = data.get('check_outs', {})
        
        # Combine check-ins and check-outs into one DataFrame for Plotly
        df = pd.DataFrame({
            'Hour': list(check_ins.keys()) + list(check_outs.keys()),
            'Count': list(check_ins.values()) + list(check_outs.values()),
            'Type': ['Check-In'] * len(check_ins) + ['Check-Out'] * len(check_outs)
        })

        fig = px.bar(df, x='Hour', y='Count', color='Type',
                     title='Check-Ins and Check-Outs by Hour',
                     labels={'Hour': 'Hour of Day', 'Count': 'Count'})
        
        plot(fig)

    except requests.exceptions.RequestException as e:
        messagebox.showerror("Error", f"Failed to fetch data: {str(e)}")

# Function to get leave counts by department
def fetch_department_leave_counts():
    try:
        response = requests.get('http://localhost:5000/api/analytics/department-leave')
        response.raise_for_status()
        data = response.json()
        
        # Create a bar plot for department leave counts
        df = pd.DataFrame(list(data.items()), columns=['catagory', 'Leave Count'])
        
        fig = px.bar(df, 
              x='Leave Count', 
              y='catagory', 
              title='Total Leave Days by Department',
              orientation='h',  # Horizontal bar chart
              color='Leave Count',  # Color by total leave days
              color_continuous_scale='Viridis')  # Color scale
        
        # Update layout for better aesthetics
        fig.update_layout(xaxis_title='Total Leave Days',
                  yaxis_title='Department',
                  showlegend=False)
        plot(fig)

    except requests.exceptions.RequestException as e:
        messagebox.showerror("Error", f"Failed to fetch data: {str(e)}")

# Function to get login frequency
def fetch_login_frequency():
    try:
        response = requests.get('http://localhost:5000/api/analytics/login-frequency')
        response.raise_for_status()
        data = response.json()
        
        # Create a bar plot for login frequency
        df = pd.DataFrame(list(data.items()), columns=['Day', 'Login Frequency'])
        
        fig = px.bar(df, 
                     x='Day', 
                     y='Login Frequency', 
                     title='Login Frequency by Day of the Week', 
                     color='Day',
                     color_continuous_scale='Viridis'
        )
        plot(fig)

    except requests.exceptions.RequestException as e:
        messagebox.showerror("Error", f"Failed to fetch data: {str(e)}")

# Create main Tkinter window
root = tk.Tk()
root.title("Analytics Dashboard")

# Create buttons for each functionality
btn_today_analytics = tk.Button(root, text="Today's Analytics", command=fetch_today_analytics)
btn_today_analytics.pack(pady=10)

btn_department_leave = tk.Button(root, text="Department Leave Counts", command=fetch_department_leave_counts)
btn_department_leave.pack(pady=10)

btn_login_frequency = tk.Button(root, text="Login Frequency", command=fetch_login_frequency)
btn_login_frequency.pack(pady=10)

# Run the Tkinter main loop
root.mainloop()
