import requests
import pandas as pd
import plotly.graph_objs as go
from plotly.offline import plot
import tkinter as tk
from tkinter import messagebox

# Function to fetch predictions from the Flask API and plot them
def fetch_and_plot():
    try:
        # Make a request to the Flask API
        response = requests.post('http://localhost:5000/predict')
        data = response.json()

        print(data)  # Debug: Print the raw data

        if 'predictions' not in data:
            messagebox.showerror("Error", "Invalid response from the server")
            return

        # Prepare data for plotting
        predictions = data['predictions']
        df_predictions = pd.DataFrame(predictions)

        print(df_predictions)  # Debug: Print the DataFrame

        # Convert 'ds' to datetime and format it to show only the date
        df_predictions['ds'] = pd.to_datetime(df_predictions['ds'])

        # Check if the DataFrame is empty
        if df_predictions.empty:
            messagebox.showerror("Error", "No data to plot")
            return

       
        # Create a vertical bar chart with a custom color scale (light red to light purple)
        fig = go.Figure()

        fig.add_trace(go.Bar(
            x=df_predictions['ds'].dt.strftime('%A, %d-%m-%Y'), 
            y=df_predictions['yhat'], 
            marker=dict(
                color=df_predictions['yhat'], 
                colorscale=[
                    [0, '#7F9B5C'],  
                    [1, '#B0B0B0']        
                ], 
                showscale=True,                  # Show the color scale
                colorbar=dict(title="Predicted Values")  # Add title for color bar
            ),
        ))

        # Update layout to customize axes
        fig.update_layout(
            title='Employee Count of Upcomming week',
            xaxis_title='Date',
            yaxis_title='Predicted Employee Count',
            xaxis=dict(title='Date with Day Names'),
            yaxis=dict(title='Number of Employees'),
            bargap=0.2  # Adjust bar gap for better appearance
        )

        # Save the figure to an HTML file
        plot_file = 'employee_predictions_bar.html'
        plot(fig, filename=plot_file, auto_open=True)

    except Exception as e:
        messagebox.showerror("Error", str(e))

# Create the main Tkinter window
root = tk.Tk()
root.title("Employee Count Predictions")

# Create a button to fetch predictions
fetch_button = tk.Button(root, text="Fetch Predictions", command=fetch_and_plot)
fetch_button.pack(pady=20)

# Start the Tkinter event loop
root.mainloop()
