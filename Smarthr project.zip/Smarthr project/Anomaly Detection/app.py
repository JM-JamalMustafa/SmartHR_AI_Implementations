from flask import Flask, jsonify
import pandas as pd
from pymongo import MongoClient
from geopy.distance import geodesic
import joblib
from datetime import datetime

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['admin']  # Replace with your database name
collection = db['data']  # Replace with your collection name

# Load your trained model
model = joblib.load('D:/Smarthr project/Anomaly Detection/xgboost_model.pkl')

# Example office location (latitude, longitude)
office_location = (24.434181, 56.580044)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Fetch today's date
        today = datetime.now().date()

        # Query MongoDB to get today's records
        data = list(collection.find({}))  # Get all records for demo, adjust as needed
        
        # Convert to DataFrame
        df1 = pd.DataFrame(data)
        df = df1.head()
# Drop the `_id` column
        if '_id' in df.columns:
            df.drop('_id', axis=1, inplace=True)

        # # Convert `login_at` field to datetime if it exists, and extract today's data
        # df['loginAt'] = pd.to_datetime(df['loginAt'], errors='coerce')  # Handle invalid dates as NaT
        # df = df[df['loginAt'].dt.date == today]  # Filter today's data

        # if df.empty:
        #     return jsonify({"error": "No data found for today"}), 400

        # Ensure that `loc` contains latitude and longitude
        df['location.latitude'] = df['location'].apply(lambda loc: loc['latitude'] if isinstance(loc, dict) else None)
        df['location.longitude'] = df['location'].apply(lambda loc: loc['longitude'] if isinstance(loc, dict) else None)

        # Check if latitude and longitude are available
        if 'location.latitude' not in df.columns or 'location.longitude' not in df.columns:
            return jsonify({"error": "Required location fields are missing in the data"}), 400

        # Step 1: Handle NaN values in latitude/longitude
        df['location.latitude'].fillna(df['location.latitude'].mean(), inplace=True)
        df['location.longitude'].fillna(df['location.longitude'].mean(), inplace=True)

        # Step 2: Calculate the distance from the office
        df['login_location'] = df.apply(lambda row: (row['location.latitude'], row['location.longitude']), axis=1)
        df['distance_from_office'] = df['login_location'].apply(lambda x: geodesic(office_location, x).km)

        # Step 3: Select relevant columns for prediction
        X = df[['location.latitude', 'location.longitude', 'distance_from_office']]

        # Step 4: Make predictions
        predictions = model.predict(X)

        # Step 5: Add predictions to the DataFrame
        df['anomaly'] = predictions

# Create a response list

        response = []
        for index, row in df.iterrows():
            # Only include relevant information in the response
            if row['anomaly'] == 1:  # Anomaly detected
                response.append({
                    'employeeId': row['employeeId'],
                    'distance_from_office': row['distance_from_office'],
                    'status': 'Anomaly',
                    'location': {  # Include location information
                        'latitude': row['location.latitude'],  # Ensure this column exists
                        'longitude': row['location.longitude']  # Ensure this column exists
                    }
                })
            else:  # Normal case
                response.append({
                    'employeeId': row['employeeId'],
                    'distance_from_office': row['distance_from_office'],
                    'status': 'Normal',
                    'location': {  # Include location information
                        'latitude': row['location.latitude'],  # Ensure this column exists
                        'longitude': row['location.longitude']  # Ensure this column exists
                    }
                })


        return jsonify({"predictions": response}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400



if __name__ == '__main__':
    app.run(debug=True)
